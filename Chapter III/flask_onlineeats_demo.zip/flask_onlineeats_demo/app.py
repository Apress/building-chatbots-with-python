import random, json

from flask import Flask, jsonify, request
app = Flask(__name__)

order_statuses = ["It's on the way",
				  "Restaurant is preparing the food",
				  "Your order is confirmed and being prepared",
				  "Rider has picked up your food, please wait for another 10-15 minutes",
				  "We are still awaiting confirmation from the restaurant. We are on it."]



@app.route('/onlineeatsbot/api/v1.0/order_status/', methods=['POST'])
def get_order_status():
	order_details = {}
	try:
		data = json.loads(request.data)
		# print(data)
		order_id = data["queryResult"]["parameters"]["order_id"]
		intent_name = data["queryResult"]["intent"]["displayName"]
		order_text = random.choice(order_statuses)
		# print (order_id, intent_name)
		bot_resp = "Order ID: {}. ".format(order_id) + order_text
		if intent_name == "user_order_id":
			order_details = {"fulfillmentText": bot_resp,
						 	 "payload": {"facebook": {
	   										 "text": bot_resp
	  						}}}
	except Exception as e:
		print(e)
		pass
	# print (jsonify(order_details))
	return jsonify(order_details)
