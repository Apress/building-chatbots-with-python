import os
os.system("nohup python3 -m rasa_core_sdk.endpoint --actions actions --port 5055 &")