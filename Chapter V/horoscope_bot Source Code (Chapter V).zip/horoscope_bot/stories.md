## Generated Story 3797421409943253925
* greeting
    - utter_greet
* I want to know my horoscope
    - utter_ask_horoscope_sign
* get_horoscope

## Generated Story 7304374603374920907
* greeting
    - utter_greet
* what is my todays horoscope?
    - utter_ask_horoscope_sign
* Cancer

## Generated Story -6877464862083507836
* greeting
    - utter_greet
* get_horoscope
    - utter_ask_horoscope_sign
* get_horoscope{"horoscope_sign": "capricorn"}
    - slot{"horoscope_sign": "capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "capricorn"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story 7588760327949496137
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "capricorn"}
    - slot{"horoscope_sign": "capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "capricorn"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story 6845943438978619706
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "capricorn"}
    - slot{"horoscope_sign": "capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "capricorn"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story 1931416802985863987
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "capricorn"}
    - slot{"horoscope_sign": "capricorn"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "capricorn"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story 6210960791450553104
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "aries"}
    - slot{"horoscope_sign": "aries"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "aries"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story 6044375431133958027
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "aquarius"}
    - slot{"horoscope_sign": "aquarius"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "aquarius"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story 5252430453071168826
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "gemini"}
    - slot{"horoscope_sign": "gemini"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "gemini"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story -8736642897409435557
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "leo"}
    - slot{"horoscope_sign": "leo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "leo"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

## Generated Story 2860376641783132292
* greeting
    - utter_greet
* get_horoscope{"horoscope_sign": "leo"}
    - slot{"horoscope_sign": "leo"}
    - get_todays_horoscope
    - slot{"horoscope_sign": "leo"}
    - utter_subscribe
* subscription{"subscribe": "True"}
    - slot{"subscribe": "True"}
    - subscribe_user
    - slot{"subscribe": true}

